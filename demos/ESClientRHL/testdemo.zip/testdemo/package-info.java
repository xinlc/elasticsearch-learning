/**
 * @program: esclientrhl
 * @description: 请构建一个springboot程序，并引入esclientrhl，配置好es服务即可做相关测试demo的调用
 * TestAggs是测试聚合相关的方法
 * TestCRUD是测试索引数据增删改查的相关方法
 * TestIndex是测试创建删除索引的相关方法
 * TestLowLevelClient是测试LowLevelClient的方法
 * 方法上我没写注释，请大家对照readme
 * @author: X-Pacific zhang 
 * @create: 2019-06-07 14:28
 **/